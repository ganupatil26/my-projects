package medicalstore;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {

    JLabel l1,l2,title;
    JTextField t1;
    JPasswordField t2;
    JButton b1;

    Login() {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("Medical Store Login");
        setSize(500,450);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        // Title
        title = new JLabel("MEDICAL STORE LOGIN");
        title.setBounds(90,40,350,40);
        title.setFont(new Font("Arial",Font.BOLD,26));
        title.setForeground(new Color(0,102,204));
        add(title);

        Font lf = new Font("Arial",Font.BOLD,16);
        Font tf = new Font("Arial",Font.PLAIN,16);

        l1 = new JLabel("Username:");
        l1.setBounds(70,130,120,30);
        l1.setFont(lf);
        add(l1);

        t1 = new JTextField();
        t1.setBounds(190,130,220,35);
        t1.setFont(tf);
        add(t1);

        l2 = new JLabel("Password:");
        l2.setBounds(70,200,120,30);
        l2.setFont(lf);
        add(l2);

        t2 = new JPasswordField();
        t2.setBounds(190,200,220,35);
        t2.setFont(tf);
        add(t2);

        b1 = new JButton("Login");
        b1.setBounds(180,290,130,40);
        b1.setFont(new Font("Arial",Font.BOLD,18));
        b1.setBackground(new Color(0,153,76));
        b1.setForeground(Color.WHITE);
        add(b1);

        b1.addActionListener(this);

        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        String user = t1.getText();
        String pass = t2.getText();

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "select * from login where username=? and password=?");

            ps.setString(1,user);
            ps.setString(2,pass);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                JOptionPane.showMessageDialog(this,"Login Success");
                new Dashboard();
                dispose();

            } else {

                JOptionPane.showMessageDialog(this,"Invalid Username or Password");
            }

        } catch(Exception ex) {

            System.out.println(ex);
        }
    }

    public static void main(String args[]) {

        new Login();
    }
}