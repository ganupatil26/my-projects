package medicalstore;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Billing extends JFrame implements ActionListener, KeyListener {

    JLabel l1,l2,l3,l4,l5,l6,l7;
    JTextField t1,t3,t4,t5,t6,t7;
    JComboBox cb;
    JButton b1,b2;

    Billing() {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("Medical Store Billing");
        setSize(600,620);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        // Title
        JLabel title = new JLabel("MEDICAL STORE BILLING");
        title.setBounds(120,20,400,40);
        title.setFont(new Font("Arial",Font.BOLD,24));
        title.setForeground(new Color(0,102,204));
        add(title);

        Font lf = new Font("Arial",Font.BOLD,16);
        Font tf = new Font("Arial",Font.PLAIN,15);

        l1 = new JLabel("Customer Name:");
        l1.setBounds(60,90,140,30);
        l1.setFont(lf);
        add(l1);

        t1 = new JTextField();
        t1.setBounds(220,90,260,35);
        t1.setFont(tf);
        add(t1);

        l2 = new JLabel("Medicine:");
        l2.setBounds(60,140,140,30);
        l2.setFont(lf);
        add(l2);

        cb = new JComboBox();
        cb.setBounds(220,140,260,35);
        cb.setFont(tf);
        add(cb);

        loadMedicine();
        cb.addActionListener(this);

        l3 = new JLabel("Quantity:");
        l3.setBounds(60,190,140,30);
        l3.setFont(lf);
        add(l3);

        t3 = new JTextField();
        t3.setBounds(220,190,260,35);
        t3.setFont(tf);
        add(t3);

        t3.addKeyListener(this);

        l4 = new JLabel("Price:");
        l4.setBounds(60,240,140,30);
        l4.setFont(lf);
        add(l4);

        t4 = new JTextField();
        t4.setBounds(220,240,260,35);
        t4.setEditable(false);
        t4.setFont(tf);
        add(t4);

        l5 = new JLabel("Total:");
        l5.setBounds(60,290,140,30);
        l5.setFont(lf);
        add(l5);

        t5 = new JTextField();
        t5.setBounds(220,290,260,35);
        t5.setEditable(false);
        t5.setFont(tf);
        add(t5);

        l6 = new JLabel("Mobile:");
        l6.setBounds(60,340,140,30);
        l6.setFont(lf);
        add(l6);

        t6 = new JTextField();
        t6.setBounds(220,340,260,35);
        t6.setFont(tf);
        add(t6);

        l7 = new JLabel("Address:");
        l7.setBounds(60,390,140,30);
        l7.setFont(lf);
        add(l7);

        t7 = new JTextField();
        t7.setBounds(220,390,260,35);
        t7.setFont(tf);
        add(t7);

        // Buttons
        b1 = new JButton("Save Bill");
        b1.setBounds(150,480,130,40);
        b1.setFont(new Font("Arial",Font.BOLD,16));
        b1.setBackground(new Color(0,153,76));
        b1.setForeground(Color.WHITE);
        add(b1);

        b2 = new JButton("Back");
        b2.setBounds(320,480,130,40);
        b2.setFont(new Font("Arial",Font.BOLD,16));
        b2.setBackground(new Color(220,53,69));
        b2.setForeground(Color.WHITE);
        add(b2);

        b1.addActionListener(e -> saveBill());

        b2.addActionListener(e -> {
            new Dashboard();
            dispose();
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    void loadMedicine() {

        try {
            Connection con = DBConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select name from medicine");

            while(rs.next()) {
                cb.addItem(rs.getString("name"));
            }

        } catch(Exception e) {
            System.out.println(e);
        }
    }

    public void actionPerformed(ActionEvent e) {

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "select price from medicine where name=?");

            ps.setString(1, cb.getSelectedItem().toString());

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
                t4.setText(rs.getString("price"));
            }

        } catch(Exception ex) {
            System.out.println(ex);
        }
    }

    public void keyReleased(KeyEvent e) {

        try {

            int qty = Integer.parseInt(t3.getText());
            double price = Double.parseDouble(t4.getText());

            double total = qty * price;

            t5.setText("" + total);

        } catch(Exception ex) {
            t5.setText("");
        }
    }

    public void keyPressed(KeyEvent e) {}
    public void keyTyped(KeyEvent e) {}

    void saveBill() {

        try {

            Connection con = DBConnection.getConnection();


            if(t1.getText().equals("") ||
               t3.getText().equals("") ||
               t6.getText().equals("") ||
               t7.getText().equals("")) {

                JOptionPane.showMessageDialog(this,"Please Fill All Fields");
                return;
            }


            PreparedStatement check = con.prepareStatement(
            "select quantity from medicine where name=?");

            check.setString(1, cb.getSelectedItem().toString());

            ResultSet rs = check.executeQuery();

            if(rs.next()) {

                int stock = rs.getInt("quantity");
                int qty = Integer.parseInt(t3.getText());

                if(qty > stock) {

                    JOptionPane.showMessageDialog(this,"Not Enough Stock");
                    return;
                }
            }

          
            PreparedStatement ps = con.prepareStatement(
            "insert into bill(customername,medicine,qty,price,total) values(?,?,?,?,?)");

            ps.setString(1, t1.getText());
            ps.setString(2, cb.getSelectedItem().toString());
            ps.setInt(3, Integer.parseInt(t3.getText()));
            ps.setDouble(4, Double.parseDouble(t4.getText()));
            ps.setDouble(5, Double.parseDouble(t5.getText()));

            ps.executeUpdate();

          

            PreparedStatement ps2 = con.prepareStatement(
            		"insert into customer(name,mobile,address,date,medicine,qty,total) values(?,?,?,?,?,?,?)");

            		ps2.setString(1, t1.getText());
            		ps2.setString(2, t6.getText());
            		ps2.setString(3, t7.getText());
            		ps2.setString(4, java.time.LocalDate.now().toString());
            		ps2.setString(5, cb.getSelectedItem().toString());
            		ps2.setInt(6, Integer.parseInt(t3.getText()));
            		ps2.setDouble(7, Double.parseDouble(t5.getText()));

            		ps2.executeUpdate();

           
            PreparedStatement ps3 = con.prepareStatement(
            "update medicine set quantity = quantity - ? where name=?");

            ps3.setInt(1, Integer.parseInt(t3.getText()));
            ps3.setString(2, cb.getSelectedItem().toString());

            ps3.executeUpdate();

           

            new Receipt(
                t1.getText(),
                cb.getSelectedItem().toString(),
                t3.getText(),
                t4.getText(),
                t5.getText()
            );

            JOptionPane.showMessageDialog(this,"Bill Saved Successfully");

           

            t1.setText("");
            t3.setText("");
            t4.setText("");
            t5.setText("");
            t6.setText("");
            t7.setText("");

        } catch(Exception ex) {

            System.out.println(ex);
        }
    }
}