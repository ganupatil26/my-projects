package medicalstore;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class AddMedicine extends JFrame implements ActionListener {

    JLabel title,l1,l2,l3,l4,l5;
    JTextField t1,t2,t3,t4,t5;
    JButton b1,b2;

    AddMedicine() {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("Add Medicine");
        setSize(600,560);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        // Title
        title = new JLabel("ADD MEDICINE");
        title.setBounds(190,25,250,40);
        title.setFont(new Font("Arial",Font.BOLD,28));
        title.setForeground(new Color(0,102,204));
        add(title);

        Font lf = new Font("Arial",Font.BOLD,16);
        Font tf = new Font("Arial",Font.PLAIN,15);

        l1 = new JLabel("Medicine Name:");
        l1.setBounds(70,100,140,30);
        l1.setFont(lf);
        add(l1);

        t1 = new JTextField();
        t1.setBounds(240,100,240,35);
        t1.setFont(tf);
        add(t1);

        l2 = new JLabel("Company:");
        l2.setBounds(70,160,140,30);
        l2.setFont(lf);
        add(l2);

        t2 = new JTextField();
        t2.setBounds(240,160,240,35);
        t2.setFont(tf);
        add(t2);

        l3 = new JLabel("Price:");
        l3.setBounds(70,220,140,30);
        l3.setFont(lf);
        add(l3);

        t3 = new JTextField();
        t3.setBounds(240,220,240,35);
        t3.setFont(tf);
        add(t3);

        l4 = new JLabel("Quantity:");
        l4.setBounds(70,280,140,30);
        l4.setFont(lf);
        add(l4);

        t4 = new JTextField();
        t4.setBounds(240,280,240,35);
        t4.setFont(tf);
        add(t4);

        l5 = new JLabel("Expiry Date:");
        l5.setBounds(70,340,140,30);
        l5.setFont(lf);
        add(l5);

        t5 = new JTextField("2027-12-31");
        t5.setBounds(240,340,240,35);
        t5.setFont(tf);
        add(t5);

        b1 = new JButton("Save");
        b1.setBounds(150,440,120,42);
        styleButton(b1,new Color(40,167,69));
        add(b1);

        b2 = new JButton("Back");
        b2.setBounds(320,440,120,42);
        styleButton(b2,new Color(220,53,69));
        add(b2);

        b1.addActionListener(this);

        b2.addActionListener(e -> {
            new Dashboard();
            dispose();
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    void styleButton(JButton btn, Color c) {

        btn.setFont(new Font("Arial",Font.BOLD,16));
        btn.setBackground(c);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }

    public void actionPerformed(ActionEvent e) {

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "insert into medicine(name,company,price,quantity,expiry) values(?,?,?,?,?)");

            ps.setString(1,t1.getText());
            ps.setString(2,t2.getText());
            ps.setDouble(3,Double.parseDouble(t3.getText()));
            ps.setInt(4,Integer.parseInt(t4.getText()));
            ps.setString(5,t5.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,"Medicine Added Successfully");

            t1.setText("");
            t2.setText("");
            t3.setText("");
            t4.setText("");
            t5.setText("");

        } catch(Exception ex) {

            System.out.println(ex);
        }
    }
}