package medicalstore;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class ViewStock extends JFrame {

    JTable table;
    DefaultTableModel model;
    JTextField search;
    JButton b1,b2,b3,b4;
    JLabel title;

    ViewStock() {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("View Stock");
        setSize(980,580);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        // Title
        title = new JLabel("VIEW MEDICINE STOCK");
        title.setBounds(280,20,420,40);
        title.setFont(new Font("Arial",Font.BOLD,28));
        title.setForeground(new Color(0,102,204));
        add(title);

        JLabel l1 = new JLabel("Search:");
        l1.setBounds(30,85,70,30);
        l1.setFont(new Font("Arial",Font.BOLD,16));
        add(l1);

        search = new JTextField();
        search.setBounds(100,85,180,35);
        search.setFont(new Font("Arial",Font.PLAIN,15));
        add(search);

        b1 = new JButton("Search");
        b1.setBounds(300,85,110,35);
        styleButton(b1,new Color(0,123,255));
        add(b1);

        b2 = new JButton("Update Qty");
        b2.setBounds(430,85,140,35);
        styleButton(b2,new Color(40,167,69));
        add(b2);

        b3 = new JButton("Delete");
        b3.setBounds(590,85,110,35);
        styleButton(b3,new Color(220,53,69));
        add(b3);

        b4 = new JButton("Back");
        b4.setBounds(720,85,110,35);
        styleButton(b4,new Color(108,117,125));
        add(b4);

        model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Company");
        model.addColumn("Price");
        model.addColumn("Qty");
        model.addColumn("Expiry");

        table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial",Font.PLAIN,14));
        table.getTableHeader().setFont(new Font("Arial",Font.BOLD,15));

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30,145,900,350);
        add(sp);

        loadData("");

        // Low Stock Highlight
        table.setDefaultRenderer(Object.class,new DefaultTableCellRenderer() {

            public Component getTableCellRendererComponent(
            JTable table,Object value,boolean isSelected,
            boolean hasFocus,int row,int col) {

                Component c = super.getTableCellRendererComponent(
                table,value,isSelected,hasFocus,row,col);

                int qty = Integer.parseInt(
                table.getValueAt(row,4).toString());

                if(qty < 10) {
                    c.setBackground(new Color(255,204,204));
                } else {
                    c.setBackground(Color.WHITE);
                }

                return c;
            }
        });

        // Search
        b1.addActionListener(e -> loadData(search.getText()));

        // Update
        b2.addActionListener(e -> updateQty());

        // Delete
        b3.addActionListener(e -> deleteMedicine());

        // Back
        b4.addActionListener(e -> {
            new Dashboard();
            dispose();
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    void styleButton(JButton btn, Color c) {

        btn.setFont(new Font("Arial",Font.BOLD,14));
        btn.setBackground(c);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }

    void loadData(String name) {

        try {

            model.setRowCount(0);

            Connection con = DBConnection.getConnection();

            PreparedStatement ps;

            if(name.equals("")) {
                ps = con.prepareStatement("select * from medicine");
            } else {
                ps = con.prepareStatement(
                "select * from medicine where name like ?");
                ps.setString(1,"%"+name+"%");
            }

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                model.addRow(new Object[]{

                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("company"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("expiry")
                });
            }

        } catch(Exception e) {
            System.out.println(e);
        }
    }

    void updateQty() {

        try {

            int row = table.getSelectedRow();

            if(row == -1) {
                JOptionPane.showMessageDialog(this,"Select Row");
                return;
            }

            String id = table.getValueAt(row,0).toString();

            String qty = JOptionPane.showInputDialog(
            this,"Enter New Quantity");

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "update medicine set quantity=? where id=?");

            ps.setInt(1,Integer.parseInt(qty));
            ps.setInt(2,Integer.parseInt(id));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,"Updated");

            loadData("");

        } catch(Exception e) {
            System.out.println(e);
        }
    }

    void deleteMedicine() {

        try {

            int row = table.getSelectedRow();

            if(row == -1) {
                JOptionPane.showMessageDialog(this,"Select Row");
                return;
            }

            String id = table.getValueAt(row,0).toString();

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "delete from medicine where id=?");

            ps.setInt(1,Integer.parseInt(id));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,"Deleted");

            loadData("");

        } catch(Exception e) {
            System.out.println(e);
        }
    }
}