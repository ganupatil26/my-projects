package medicalstore;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Customer extends JFrame {

    JTable table;
    DefaultTableModel model;
    JTextField search;
    JButton b1,b2,b3;
    JLabel title;

    Customer() {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("Customer Data");
        setSize(1100,580);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        // Title
        title = new JLabel("CUSTOMER PURCHASE HISTORY");
        title.setBounds(260,20,520,40);
        title.setFont(new Font("Arial",Font.BOLD,28));
        title.setForeground(new Color(0,102,204));
        add(title);

        JLabel l1 = new JLabel("Search:");
        l1.setBounds(30,85,70,30);
        l1.setFont(new Font("Arial",Font.BOLD,16));
        add(l1);

        search = new JTextField();
        search.setBounds(100,85,220,35);
        search.setFont(new Font("Arial",Font.PLAIN,15));
        add(search);

        b1 = new JButton("Search");
        b1.setBounds(340,85,110,35);
        styleButton(b1,new Color(0,123,255));
        add(b1);

        b2 = new JButton("Delete");
        b2.setBounds(470,85,110,35);
        styleButton(b2,new Color(220,53,69));
        add(b2);

        b3 = new JButton("Back");
        b3.setBounds(600,85,110,35);
        styleButton(b3,new Color(108,117,125));
        add(b3);

        model = new DefaultTableModel();

        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Mobile");
        model.addColumn("Address");
        model.addColumn("Medicine");
        model.addColumn("Qty");
        model.addColumn("Total");
        model.addColumn("Date");

        table = new JTable(model);

        table.setRowHeight(28);
        table.setFont(new Font("Arial",Font.PLAIN,14));
        table.getTableHeader().setFont(new Font("Arial",Font.BOLD,15));

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30,145,1020,350);
        add(sp);

        loadData("");

        // Search
        b1.addActionListener(e -> loadData(search.getText()));

        // Delete
        b2.addActionListener(e -> deleteCustomer());

        // Back
        b3.addActionListener(e -> {
            new Dashboard();
            dispose();
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    void styleButton(JButton btn, Color c) {

        btn.setFont(new Font("Arial",Font.BOLD,14));
        btn.setBackground(c);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }

    void loadData(String name) {

        try {

            model.setRowCount(0);

            Connection con = DBConnection.getConnection();

            PreparedStatement ps;

            if(name.equals("")) {

                ps = con.prepareStatement("select * from customer");

            } else {

                ps = con.prepareStatement(
                "select * from customer where name like ?");

                ps.setString(1,"%"+name+"%");
            }

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                model.addRow(new Object[]{

                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("mobile"),
                    rs.getString("address"),
                    rs.getString("medicine"),
                    rs.getInt("qty"),
                    rs.getDouble("total"),
                    rs.getString("date")
                });
            }

        } catch(Exception e) {

            System.out.println(e);
        }
    }

    void deleteCustomer() {

        try {

            int row = table.getSelectedRow();

            if(row == -1) {

                JOptionPane.showMessageDialog(this,"Select Row");
                return;
            }

            String id = table.getValueAt(row,0).toString();

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "delete from customer where id=?");

            ps.setInt(1,Integer.parseInt(id));

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,"Deleted");

            loadData("");

        } catch(Exception e) {

            System.out.println(e);
        }
    }
}