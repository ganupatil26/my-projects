package medicalstore;

import java.awt.Color;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Receipt extends JFrame {

    JTextArea area;
    JButton b1,b2;

    Receipt(String cname,String med,String qty,String price,String total) {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("Bill Receipt");
        setSize(500,620);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        JLabel title = new JLabel("BILL RECEIPT");
        title.setBounds(165,20,220,35);
        title.setFont(new Font("Arial",Font.BOLD,26));
        title.setForeground(new Color(0,102,204));
        add(title);

        area = new JTextArea();
        area.setBounds(55,80,370,400);
        area.setFont(new Font("Monospaced",Font.PLAIN,16));
        area.setEditable(false);
        area.setBackground(Color.WHITE);
        area.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        Date d = new Date();

        String date =
        new SimpleDateFormat("dd-MM-yyyy").format(d);

        String time =
        new SimpleDateFormat("hh:mm a").format(d);

        area.setText(

        "=================================\n" +
        "      SHREE MEDICAL STORE\n" +
        "        Pune Maharashtra\n" +
        "=================================\n\n" +

        "Date : " + date + "\n" +
        "Time : " + time + "\n\n" +

        "Customer : " + cname + "\n" +
        "Medicine : " + med + "\n" +
        "Quantity : " + qty + "\n" +
        "Price    : " + price + "\n" +
        "---------------------------------\n" +
        "Total    : " + total + "\n" +
        "=================================\n\n" +

        "      Thank You Visit Again\n" +
        "        Get Well Soon 😊"

        );

        add(area);

        b1 = new JButton("Print");
        b1.setBounds(110,520,110,40);
        styleButton(b1,new Color(40,167,69));
        add(b1);

        b2 = new JButton("Back");
        b2.setBounds(270,520,110,40);
        styleButton(b2,new Color(220,53,69));
        add(b2);

        b1.addActionListener(e -> {

            try {
                area.print();
            } catch(Exception ex) {
                System.out.println(ex);
            }
        });

        b2.addActionListener(e -> {
            new Dashboard();
            dispose();
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    void styleButton(JButton btn, Color c) {

        btn.setFont(new Font("Arial",Font.BOLD,16));
        btn.setBackground(c);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }
}