package medicalstore;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Dashboard extends JFrame implements ActionListener {

    JButton b1,b2,b3,b4,b5;
    JLabel title;

    Dashboard() {
    	ImageIcon icon = new ImageIcon("src/images/medical.png");
    	setIconImage(icon.getImage());
        setTitle("Medical Store Dashboard");
        setSize(650,520);
        setLayout(null);
        getContentPane().setBackground(new Color(245,248,252));

        // Title
        title = new JLabel("MEDICAL STORE DASHBOARD");
        title.setBounds(110,30,450,40);
        title.setFont(new Font("Arial",Font.BOLD,26));
        title.setForeground(new Color(0,102,204));
        add(title);

        Font bf = new Font("Arial",Font.BOLD,16);

        b1 = new JButton("Add Medicine");
        b1.setBounds(90,120,200,50);
        styleButton(b1,bf,new Color(0,123,255));
        add(b1);

        b2 = new JButton("View Stock");
        b2.setBounds(340,120,200,50);
        styleButton(b2,bf,new Color(23,162,184));
        add(b2);

        b3 = new JButton("Billing");
        b3.setBounds(90,220,200,50);
        styleButton(b3,bf,new Color(40,167,69));
        add(b3);

        b4 = new JButton("Customer Data");
        b4.setBounds(340,220,200,50);
        styleButton(b4,bf,new Color(255,193,7));
        add(b4);

        b5 = new JButton("Logout");
        b5.setBounds(220,340,200,50);
        styleButton(b5,bf,new Color(220,53,69));
        add(b5);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);

        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    void styleButton(JButton btn, Font f, Color c) {

        btn.setFont(f);
        btn.setBackground(c);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
    }

    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==b1) {
            new AddMedicine();
            dispose();
        }

        if(e.getSource()==b2) {
            new ViewStock();
            dispose();
        }

        if(e.getSource()==b3) {
            new Billing();
            dispose();
        }

        if(e.getSource()==b4) {
            new Customer();
            dispose();
        }

        if(e.getSource()==b5) {
            new Login();
            dispose();
        }
    }
}